using System;
using System.Collections.Generic;
using System.IO;

// ---------- Task 3 : create and display the five accounts ----------
const string LogFile = "failed_operations.txt";

var rnd = new Random();
string[] names = { "Ada", "Linus", "Grace", "Alan", "Margaret" };
var accounts = new List<BankAccount>();

for (int i = 0; i < names.Length; i++)
{
    accounts.Add(new BankAccount
    {
        Id = i + 1,
        CustomerName = names[i],
        Balance = rnd.Next(5000, 100001)   // upper bound is exclusive -> 5000..100000
    });
}

PrintAccounts();

// ---------- Section 7 : loop until the user types q ----------
while (true)
{
    Console.WriteLine();
    Console.WriteLine("Menu: [W] Withdraw  [D] Deposit  [T] Transfer  [L] List accounts  [Q] Quit");
    Console.Write("Choice: ");
    string? line = Console.ReadLine();
    if (line == null) break;                 // end of input
    string choice = line.Trim().ToLower();

    if (choice == "q") break;

    switch (choice)
    {
        case "w": DoWithdraw(); break;
        case "d": DoDeposit(); break;
        case "t": DoTransfer(); break;
        case "l": PrintAccounts(); break;
        default: Console.WriteLine("Unknown choice."); break;
    }
}

Console.WriteLine("Goodbye.");

// =====================================================================
// Local functions
// =====================================================================

void PrintAccounts()
{
    Console.WriteLine($"{"Id",-4}{"Customer",-11}{"Balance"}");
    foreach (var a in accounts)
        Console.WriteLine($"{a.Id,-4}{a.CustomerName,-11}{a.Balance}");
}

// Reads an id and returns the account, or null (with a message) if invalid / not found.
BankAccount? AskAccount(string prompt)
{
    Console.Write(prompt);
    if (!int.TryParse(Console.ReadLine(), out int id))
    {
        Console.WriteLine("Invalid input");
        return null;
    }

    BankAccount? account = accounts.Find(a => a.Id == id);
    if (account == null)                     // Find returns null when nothing matches
    {
        Console.WriteLine("Account not found");
        LogFailure($"LOOKUP id {id}", "Account not found");
    }
    return account;
}

bool AskAmount(string prompt, out decimal amount)
{
    Console.Write(prompt);
    if (!decimal.TryParse(Console.ReadLine(), out amount))
    {
        Console.WriteLine("Invalid input");
        return false;
    }
    return true;
}

// ---------- Task 4 : withdraw and catch ----------
void DoWithdraw()
{
    BankAccount? account = AskAccount("Account id: ");
    if (account == null) return;
    if (!AskAmount("Amount to withdraw: ", out decimal amount)) return;

    try
    {
        account.Withdraw(amount);
        Console.WriteLine($"Withdrawal OK. New balance = {account.Balance}");
    }
    catch (InsufficientFundsException ex)      // specific catch blocks first
    {
        Console.WriteLine($"ERROR: {ex.Message}");
        Console.WriteLine($"       Balance = {ex.Balance}, requested = {ex.Requested}");
        LogFailure($"WITHDRAW account {account.Id} amount {amount}",
                   $"{ex.Message} (balance {ex.Balance})");
    }
    catch (ArgumentOutOfRangeException)
    {
        Console.WriteLine("ERROR: Invalid amount (it must be greater than 0).");
        LogFailure($"WITHDRAW account {account.Id} amount {amount}", "Invalid amount");
    }
    finally
    {
        Console.WriteLine("Operation finished.");
    }
}

// ---------- Section 7 : deposit ----------
void DoDeposit()
{
    BankAccount? account = AskAccount("Account id: ");
    if (account == null) return;
    if (!AskAmount("Amount to deposit: ", out decimal amount)) return;

    try
    {
        account.Deposit(amount);
        Console.WriteLine($"Deposit OK. New balance = {account.Balance}");
    }
    catch (ArgumentOutOfRangeException)
    {
        Console.WriteLine("ERROR: Invalid amount (it must be greater than 0).");
        LogFailure($"DEPOSIT account {account.Id} amount {amount}", "Invalid amount");
    }
    finally
    {
        Console.WriteLine("Operation finished.");
    }
}

// ---------- Section 7 : transfer (reuses Withdraw) ----------
void DoTransfer()
{
    BankAccount? from = AskAccount("From account id: ");
    if (from == null) return;
    BankAccount? to = AskAccount("To account id: ");
    if (to == null) return;
    if (!AskAmount("Amount to transfer: ", out decimal amount)) return;

    string operation = $"TRANSFER {from.Id} -> {to.Id} amount {amount}";
    try
    {
        BankAccount.Transfer(from, to, amount);
        Console.WriteLine($"Transfer OK. {from.CustomerName} = {from.Balance}, {to.CustomerName} = {to.Balance}");
    }
    catch (InsufficientFundsException ex)
    {
        Console.WriteLine($"ERROR: {ex.Message}");
        Console.WriteLine($"       Balance = {ex.Balance}, requested = {ex.Requested}");
        LogFailure(operation, $"{ex.Message} (balance {ex.Balance})");
    }
    catch (ArgumentOutOfRangeException)        // must come BEFORE ArgumentException (it derives from it)
    {
        Console.WriteLine("ERROR: Invalid amount (it must be greater than 0).");
        LogFailure(operation, "Invalid amount");
    }
    catch (ArgumentException ex)               // same source and destination account
    {
        Console.WriteLine($"ERROR: {ex.Message}");
        LogFailure(operation, ex.Message);
    }
    finally
    {
        Console.WriteLine("Operation finished.");
    }
}

// ---------- Section 7 : write failed operations to a file (using + StreamWriter) ----------
void LogFailure(string operation, string reason)
{
    try
    {
        // append: true -> add to the end of the file instead of overwriting it
        // using -> the file is closed automatically, even if an exception occurs
        using (var writer = new StreamWriter(LogFile, append: true))
        {
            writer.WriteLine($"{DateTime.Now:yyyy-MM-dd HH:mm:ss} | {operation} | {reason}");
        }
        Console.WriteLine($"       (logged to {LogFile})");
    }
    catch (IOException ex)
    {
        Console.WriteLine($"Could not write to the log file: {ex.Message}");
    }
}
