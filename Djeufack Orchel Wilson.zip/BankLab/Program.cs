﻿/*
using System;
using System.Collections.Generic;

namespace BankLab
{
    public class InsufficientFundsException : Exception
    {
        public decimal Balance { get; }
        public decimal Requested { get; }

        public InsufficientFundsException() : base() { }
        public InsufficientFundsException(string message) : base(message) { }
        public InsufficientFundsException(string message, Exception innerException) : base(message, innerException) { }

        public InsufficientFundsException(decimal balance, decimal requested) 
            : base("Insufficient bank account balance")
        {
            Balance = balance;
            Requested = requested;
        }
    }

    public class BankAccount
    {
        public int Id { get; set; }
        public string CustomerName { get; set; } = string.Empty;
        public decimal Balance { get; set; }

        public void Withdraw(decimal amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(amount), "Amount must be greater than zero.");
            }

            if (amount > Balance)
            {
                throw new InsufficientFundsException(Balance, amount);
            }

            Balance -= amount;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Task 3: Create the five accounts
            var rnd = new Random();
            string[] names = { "Ada", "Linus", "Grace", "Alan", "Margaret" };
            var accounts = new List<BankAccount>();

            for (int i = 0; i < names.Length; i++)
            {
                accounts.Add(new BankAccount
                {
                    Id = i + 1,
                    CustomerName = names[i],
                    Balance = rnd.Next(5000, 100001)
                });
            }

            // Display the list
            Console.WriteLine("Id  Customer     Balance");
            foreach (var acc in accounts)
            {
                Console.WriteLine($"{acc.Id,-3} {acc.CustomerName,-12} {acc.Balance}");
            }
        }
    }

*/


using System;
using System.Collections.Generic;
using System.IO;

namespace BankLab
{
    public class InsufficientFundsException : Exception
    {
        public decimal Balance { get; }
        public decimal Requested { get; }

        public InsufficientFundsException() : base() { }
        public InsufficientFundsException(string message) : base(message) { }
        public InsufficientFundsException(string message, Exception innerException) : base(message, innerException) { }

        public InsufficientFundsException(decimal balance, decimal requested) 
            : base("Insufficient bank account balance")
        {
            Balance = balance;
            Requested = requested;
        }
    }

    public class BankAccount
    {
        public int Id { get; set; }
        public string CustomerName { get; set; } = string.Empty;
        public decimal Balance { get; set; }

        public void Withdraw(decimal amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(amount), "Amount must be greater than zero.");
            }

            if (amount > Balance)
            {
                throw new InsufficientFundsException(Balance, amount);
            }

            Balance -= amount;
        }

        // Optional Feature: Deposit Method
        public void Deposit(decimal amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(amount), "Deposit amount must be greater than zero.");
            }
            Balance += amount;
        }

        // Optional Feature: Transfer Method (reuses Withdraw)
        public void Transfer(BankAccount targetAccount, decimal amount)
        {
            if (targetAccount == null)
            {
                throw new ArgumentNullException(nameof(targetAccount), "Target account cannot be null.");
            }

            // Withdraw from current account (will throw exceptions if invalid/insufficient)
            this.Withdraw(amount);

            // Deposit into target account
            targetAccount.Deposit(amount);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Task 3: Create the five accounts
            var rnd = new Random();
            string[] names = { "Ada", "Linus", "Grace", "Alan", "Margaret" };
            var accounts = new List<BankAccount>();

            for (int i = 0; i < names.Length; i++)
            {
                accounts.Add(new BankAccount
                {
                    Id = i + 1,
                    CustomerName = names[i],
                    Balance = rnd.Next(5000, 100001)
                });
            }

            // Display the initial list
            Console.WriteLine("Id  Customer     Balance");
            foreach (var acc in accounts)
            {
                Console.WriteLine($"{acc.Id,-3} {acc.CustomerName,-12} {acc.Balance}");
            }
            Console.WriteLine("-----------------------------------");
            Console.WriteLine("Commands: [w] Withdraw, [d] Deposit, [t] Transfer, [q] Quit");

            // Optional Feature: Loop until user types 'q'
            while (true)
            {
                Console.Write("\nChoose action ([w]ithdraw, [d]eposit, [t]ransfer, [q]uit): ");
                string action = Console.ReadLine()?.Trim().ToLower();

                if (action == "q")
                {
                    break;
                }

                if (action != "w" && action != "d" && action != "t")
                {
                    Console.WriteLine("Invalid action. Please choose w, d, t, or q.");
                    continue;
                }

                // Handle Deposit
                if (action == "d")
                {
                    Console.Write("Account id to deposit into: ");
                    if (int.TryParse(Console.ReadLine(), out int depositId))
                    {
                        var targetAcc = accounts.Find(a => a.Id == depositId);
                        if (targetAcc == null)
                        {
                            Console.WriteLine("Account not found.");
                            continue;
                        }

                        Console.Write("Amount to deposit: ");
                        if (decimal.TryParse(Console.ReadLine(), out decimal depAmount))
                        {
                            try
                            {
                                targetAcc.Deposit(depAmount);
                                Console.WriteLine($"Deposit OK. New balance for {targetAcc.CustomerName} = {targetAcc.Balance}");
                            }
                            catch (ArgumentOutOfRangeException ex)
                            {
                                Console.WriteLine($"ERROR: {ex.Message}");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Invalid amount format.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid ID format.");
                    }
                    continue;
                }

                // Handle Transfer
                if (action == "t")
                {
                    Console.Write("Source account id: ");
                    if (int.TryParse(Console.ReadLine(), out int srcId))
                    {
                        var srcAcc = accounts.Find(a => a.Id == srcId);
                        if (srcAcc == null)
                        {
                            Console.WriteLine("Source account not found.");
                            continue;
                        }

                        Console.Write("Target account id: ");
                        if (int.TryParse(Console.ReadLine(), out int destId))
                        {
                            var destAcc = accounts.Find(a => a.Id == destId);
                            if (destAcc == null)
                            {
                                Console.WriteLine("Target account not found.");
                                continue;
                            }

                            Console.Write("Amount to transfer: ");
                            if (decimal.TryParse(Console.ReadLine(), out decimal transAmount))
                            {
                                try
                                {
                                    srcAcc.Transfer(destAcc, transAmount);
                                    Console.WriteLine($"Transfer OK. New balance for {srcAcc.CustomerName} = {srcAcc.Balance}, {destAcc.CustomerName} = {destAcc.Balance}");
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine($"ERROR during transfer: {ex.Message}");
                                    LogFailedOperation($"Transfer failed from ID {srcId} to {destId} amount {transAmount}: {ex.Message}");
                                }
                            }
                            else
                            {
                                Console.WriteLine("Invalid amount format.");
                            }
                        }
                    }
                    continue;
                }

                // Handle Withdraw (Action 'w')
                Console.Write("Account id: ");
                if (int.TryParse(Console.ReadLine(), out int inputId))
                {
                    var account = accounts.Find(a => a.Id == inputId);

                    if (account == null)
                    {
                        Console.WriteLine("Account not found.");
                    }
                    else
                    {
                        Console.Write("Amount to withdraw: ");
                        if (decimal.TryParse(Console.ReadLine(), out decimal inputAmount))
                        {
                            try
                            {
                                account.Withdraw(inputAmount);
                                Console.WriteLine($"Withdrawal OK. New balance = {account.Balance}");
                            }
                            catch (InsufficientFundsException ex)
                            {
                                Console.WriteLine($"ERROR: {ex.Message}");
                                Console.WriteLine($"Balance = {ex.Balance} requested = {ex.Requested}");
                                
                                // Optional Feature: Write failed operation to a file using StreamWriter
                                LogFailedOperation($"Account ID {inputId} Insufficient Funds. Balance: {ex.Balance}, Requested: {ex.Requested}");
                            }
                            catch (ArgumentOutOfRangeException ex)
                            {
                                Console.WriteLine($"ERROR: Invalid amount. {ex.Message}");
                                LogFailedOperation($"Account ID {inputId} Invalid Amount: {inputAmount}");
                            }
                            finally
                            {
                                Console.WriteLine("Operation finished.");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Invalid input. Not a number.");
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input. Not a number.");
                }
            }
        }

        // Helper method for optional file logging
        private static void LogFailedOperation(string errorMessage)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter("failed_operations.txt", true))
                {
                    writer.WriteLine($"{DateTime.Now}: {errorMessage}");
                }
            }
            catch (Exception)
            {
                // Ignore file access errors if any occur
            }
        }
    }
}