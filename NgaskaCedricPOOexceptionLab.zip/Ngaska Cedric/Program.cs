﻿using System;
using System.Collections.Generic;
using System.IO;

class InsufficientFundsException : Exception
{
    public decimal Balance { get; }
    public decimal Requested { get; }

    public InsufficientFundsException(decimal balance, decimal requested)
        : base("Insufficient funds")
    {
        Balance = balance;
        Requested = requested;
    }
}

class BankAccount
{
    public int Id { get; set; }
    public string CustomerName { get; set; } = "";
    public decimal Balance { get; set; }

    public void Deposit(decimal amount)
    {
        if (amount <= 0) throw new ArgumentOutOfRangeException();
        Balance += amount;
    }

    public void Withdraw(decimal amount)
    {
        if (amount <= 0) throw new ArgumentOutOfRangeException();

        if (amount > Balance)
            throw new InsufficientFundsException(Balance, amount);

        Balance -= amount;
    }

    public void Transfer(BankAccount to, decimal amount)
    {
        Withdraw(amount);
        to.Deposit(amount);
    }
}

class Program
{
    static List<BankAccount> accounts = new();

    static void Main()
    {
        string[] names = { "Ada", "Linus", "Grace", "Alan", "Margaret" };
        Random r = new();

        for (int i = 0; i < 5; i++)
            accounts.Add(new BankAccount
            {
                Id = i + 1,
                CustomerName = names[i],
                Balance = r.Next(5000, 100001)
            });

        while (true)
        {
            Console.WriteLine("\n1.Display  2.Deposit  3.Withdraw  4.Transfer  5.Exit");
            Console.Write("Choice: ");
            string choice = Console.ReadLine() ?? "";

            if (choice == "5" || choice.ToLower() == "q")
                break;

            try
            {
                if (choice == "1")
                {
                    foreach (var a in accounts)
                        Console.WriteLine($"{a.Id} - {a.CustomerName} - {a.Balance:0.00}");
                }
                else if (choice == "2")
                {
                    var a = GetAccount();
                    Console.Write("Amount: ");
                    a.Deposit(decimal.Parse(Console.ReadLine()!));
                    Console.WriteLine("Deposit successful.");
                }
                else if (choice == "3")
                {
                    var a = GetAccount();
                    Console.Write("Amount: ");
                    a.Withdraw(decimal.Parse(Console.ReadLine()!));
                    Console.WriteLine("Withdrawal successful.");
                }
                else if (choice == "4")
                {
                    Console.Write("From ID: ");
                    var from = accounts.Find(a => a.Id == int.Parse(Console.ReadLine()!));

                    Console.Write("To ID: ");
                    var to = accounts.Find(a => a.Id == int.Parse(Console.ReadLine()!));

                    if (from == null || to == null)
                        throw new Exception("Account not found.");

                    Console.Write("Amount: ");
                    from.Transfer(to, decimal.Parse(Console.ReadLine()!));

                    Console.WriteLine("Transfer successful.");
                }
            }
            catch (InsufficientFundsException e)
            {
                Console.WriteLine($"ERROR: {e.Message}");
            }
            catch (Exception e)
            {
                Console.WriteLine($"ERROR: {e.Message}");
            }
            finally
            {
                Console.WriteLine("Operation finished.");
            }

            File.AppendAllText(
                "bank_log.txt",
                $"{DateTime.Now} - Operation: {choice}\n");
        }
    }

    static BankAccount GetAccount()
    {
        Console.Write("Account ID: ");
        var a = accounts.Find(x => x.Id == int.Parse(Console.ReadLine()!));

        if (a == null)
            throw new Exception("Account not found.");

        return a;
    }
}