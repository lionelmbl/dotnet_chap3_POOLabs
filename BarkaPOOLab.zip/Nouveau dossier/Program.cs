﻿using System;
using System.Collections.Generic;

public class InsufficientFundsException : Exception
{
    public decimal Balance { get; }
    public decimal Requested { get; }

    public InsufficientFundsException() : base() { }
    public InsufficientFundsException(string message) : base(message) { }
    public InsufficientFundsException(string message, Exception inner) : base(message, inner) { }

    public InsufficientFundsException(decimal balance, decimal requested) : base("Insufficient bank account balance")
    {
        Balance = balance;
        Requested = requested;
    }
}

public class BankAccount
{
    public int Id { get; set; }
    public string CustomerName { get; set; }
    public decimal Balance { get; set; }

    public void Withdraw(decimal amount)
    {
        if (amount <= 0)
        { throw new ArgumentOutOfRangeException(nameof(amount), "Amount must be greater than zero.");}
        
        if (amount > Balance)
        {
            throw new InsufficientFundsException(Balance, amount);
        }
        Balance -= amount;
    }
}

public class Program
{
    public static void Main()
    {
        Console.WriteLine("Hello, World!");
        Console.WriteLine();

        var rnd = new Random();
        string[] names = { "Ada", "Linus", "Grace", "Alan", "Margaret" };
        var accounts = new List<BankAccount>();

        for (int i = 0; i < names.Length; i++)
        {
            accounts.Add(new BankAccount
            {
                Id = i + 1,
                CustomerName = names[i],
                Balance = rnd.Next(5000, 100001) 
            });
        }
        Console.WriteLine($"{"Id",-5} {"Customer",-12} {"Balance",-10}");
        foreach (var acc in accounts)
        {
            Console.WriteLine($"{acc.Id,-5} {acc.CustomerName,-12} {acc.Balance,-10}");
        }
        Console.WriteLine();

        Console.Write("Account id: ");
        if (!int.TryParse(Console.ReadLine(), out int accountId))
        {
            Console.WriteLine("Invalid input");
            return;
        }
        Console.Write("Amount to withdraw: ");
        if (!decimal.TryParse(Console.ReadLine(), out decimal amount))
        {
            Console.WriteLine("Invalid input");
            return;
        }
        var account = accounts.Find(a => a.Id == accountId);
        if (account == null)
        {
            Console.WriteLine("Account not found");
            return;
        }

        try
        {
            account.Withdraw(amount);
            Console.WriteLine($"Withdrawal OK. New balance = {account.Balance}");
        }
        catch (InsufficientFundsException ex)
        {
            Console.WriteLine($"ERROR: {ex.Message}");
            Console.WriteLine($"Balance = {ex.Balance} requested = {ex.Requested}");
        }
        catch (ArgumentOutOfRangeException ex)
        {
            Console.WriteLine($"ERROR: {ex.Message}");
        }
        finally
        {
            Console.WriteLine("Operation finished.");
        }
    }
}