﻿using System;
using System.Collections.Generic;

// ---------- Tasks 3 and 4 : Program.cs ----------

var rnd = new Random();
string[] names = { "Ada", "Linus", "Grace", "Alan", "Margaret" };
var accounts = new List<BankAccount>();

// Task 3: create 5 accounts with Id = 1..5 and a random balance in [5000, 100000]
for (int i = 0; i < names.Length; i++)
{
    accounts.Add(new BankAccount
    {
        Id = i + 1,
        CustomerName = names[i],
        Balance = rnd.Next(5000, 100001)  
    });
}

Console.WriteLine("Id\tCustomer\tBalance");
foreach (var acc in accounts)
{
    Console.WriteLine($"{acc.Id}\t{acc.CustomerName}\t\t{acc.Balance}");
}
Console.WriteLine();

// Task 4: read id and amount
Console.Write("Account id: ");
if (!int.TryParse(Console.ReadLine(), out int id))
{
    Console.WriteLine("Invalid input.");
    return;
}

Console.Write("Amount to withdraw: ");
if (!decimal.TryParse(Console.ReadLine(), out decimal amount))
{
    Console.WriteLine("Invalid input.");
    return;
}

BankAccount? account = accounts.Find(a => a.Id == id);
if (account == null)
{
    Console.WriteLine("Account not found.");
    return;
}

try
{
    account.Withdraw(amount);
    Console.WriteLine($"Withdrawal OK. New balance = {account.Balance}");
}
catch (InsufficientFundsException ex)
{
    Console.WriteLine($"ERROR: {ex.Message}");
    Console.WriteLine($"       Balance = {ex.Balance}, requested = {ex.Requested}");
}
catch (ArgumentOutOfRangeException)
{
    Console.WriteLine("Invalid amount: it must be greater than 0.");
}
finally
{
    Console.WriteLine("Operation finished.");
}

// ---------- Task 1 ----------
public class InsufficientFundsException : Exception
{
    public decimal Balance { get; }
    public decimal Requested { get; }

    public InsufficientFundsException() : base() { }

    public InsufficientFundsException(string message) : base(message) { }

    public InsufficientFundsException(string message, Exception innerException)
        : base(message, innerException) { }

    public InsufficientFundsException(decimal balance, decimal requested)
        : base("Insufficient bank account balance")
    {
        Balance = balance;
        Requested = requested;
    }
}

// ---------- Task 2 ----------
public class BankAccount
{
    public int Id { get; set; }
    public string CustomerName { get; set; } = "";
    public decimal Balance { get; set; }

    public void Withdraw(decimal amount)
    {
        if (amount <= 0)
            throw new ArgumentOutOfRangeException(nameof(amount), "Amount must be greater than 0.");

        if (amount > Balance)
            throw new InsufficientFundsException(Balance, amount);

        Balance -= amount;
    }
}