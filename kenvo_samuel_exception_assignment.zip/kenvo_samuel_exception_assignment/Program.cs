﻿using System;
using System.Collections.Generic;

namespace BankApp
{
    // --- Task 1: Custom Exception ---
    public class InsufficientFundsException : Exception
    {
        public decimal Balance { get; }
        public decimal Requested { get; }

        // Standard constructors
        public InsufficientFundsException() : base() { }

        public InsufficientFundsException(string message) : base(message) { }

        public InsufficientFundsException(string message, Exception innerException) 
            : base(message, innerException) { }

        // Custom constructor required by the lab
        public InsufficientFundsException(decimal balance, decimal requested) 
            : base("Insufficient bank account balance")
        {
            Balance = balance;
            Requested = requested;
        }
    }

    // --- Task 2: BankAccount Class ---
    public class BankAccount
    {
        public int Id { get; set; }
        public string CustomerName { get; set; }
        public decimal Balance { get; set; }

        public BankAccount(int id, string customerName, decimal balance)
        {
            Id = id;
            CustomerName = customerName;
            Balance = balance;
        }

        public void Withdraw(decimal amount)
        {
            // 1. Throws ArgumentOutOfRangeException if amount <= 0
            if (amount <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(amount), "Withdrawal amount must be greater than zero.");
            }

            // 2. Throws InsufficientFundsException if amount > Balance
            if (amount > Balance)
            {
                throw new InsufficientFundsException(Balance, amount);
            }

            // 3. Otherwise subtracts the amount from the balance
            Balance -= amount;
        }
    }

    // --- Task 3 & 4: Program Execution ---
    class Program
    {
        static void Main(string[] args)
        {
            // Task 3: Build a List of 5 accounts using Random
            Random rnd = new Random();

            List<BankAccount> accounts = new List<BankAccount>
            {
                new BankAccount(1, "Alice Smith", rnd.Next(5000, 100001)),
                new BankAccount(2, "Bob Jones", rnd.Next(5000, 100001)),
                new BankAccount(3, "Charlie Brown", rnd.Next(5000, 100001)),
                new BankAccount(4, "Diana Prince", rnd.Next(5000, 100001)),
                new BankAccount(5, "Evan Wright", rnd.Next(5000, 100001))
            };

            // Display the list of accounts
            Console.WriteLine("=== Bank Accounts List ===");
            foreach (var acc in accounts)
            {
                Console.WriteLine($"ID: {acc.Id} | Name: {acc.CustomerName,-15} | Balance: {acc.Balance:C}");
            }
            Console.WriteLine(new string('-', 45));

            // Task 4: Withdraw and catch
            Console.Write("Enter Account ID to withdraw from: ");
            if (!int.TryParse(Console.ReadLine(), out int accountId))
            {
                Console.WriteLine("Invalid account ID format.");
                return;
            }

            Console.Write("Enter amount to withdraw: ");
            if (!decimal.TryParse(Console.ReadLine(), out decimal amount))
            {
                Console.WriteLine("Invalid amount format.");
                return;
            }

            // Find the account using accounts.Find(...)
            BankAccount targetAccount = accounts.Find(a => a.Id == accountId);

            if (targetAccount == null)
            {
                Console.WriteLine($"Error: Account with ID {accountId} was not found.");
                return;
            }

            // Call Withdraw inside a try block
            try
            {
                targetAccount.Withdraw(amount);
                Console.WriteLine($"\nWithdrawal successful! New balance for {targetAccount.CustomerName}: {targetAccount.Balance:C}");
            }
            catch (InsufficientFundsException ex)
            {
                // Catch InsufficientFundsException and print details
                Console.WriteLine($"\n[Insufficient Funds Exception]: {ex.Message}");
                Console.WriteLine($"  - Available Balance: {ex.Balance:C}");
                Console.WriteLine($"  - Requested Amount:  {ex.Requested:C}");
            }
            catch (ArgumentOutOfRangeException ex)
            {
                // Catch ArgumentOutOfRangeException for invalid amounts
                Console.WriteLine($"\n[Argument Out Of Range Exception]: {ex.Message}");
            }
        }
    }
}