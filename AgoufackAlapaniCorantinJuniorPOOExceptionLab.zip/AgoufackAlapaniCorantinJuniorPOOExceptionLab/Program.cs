const string LogPath = "failed_operations.log";

var rnd = new Random();
string[] names = { "Ada", "Linus", "Grace", "Alan", "Margaret" };
var accounts = new List<BankAccount>();

for (int i = 0; i < names.Length; i++)
{
    accounts.Add(new BankAccount
    {
        Id = i + 1,
        CustomerName = names[i],
        Balance = rnd.Next(5000, 100001)
    });
}

using StreamWriter? log = OpenLog();

PrintAccounts();

while (true)
{
    Console.WriteLine();
    Console.Write("Operation (w = withdraw, d = deposit, t = transfer, l = list, q = quit): ");
    string? choice = Console.ReadLine()?.Trim().ToLowerInvariant();

    if (choice is null || choice == "q")
        break;

    switch (choice)
    {
        case "w": DoWithdraw(); break;
        case "d": DoDeposit(); break;
        case "t": DoTransfer(); break;
        case "l": PrintAccounts(); break;
        default: Console.WriteLine("Unknown operation"); break;
    }
}

Console.WriteLine("Goodbye.");

void DoWithdraw()
{
    var account = ReadAccount("Account id: ", "WITHDRAW");
    if (account is null || !TryReadAmount("Amount to withdraw: ", "WITHDRAW", out decimal amount))
        return;

    Execute("WITHDRAW", $"account {account.Id}, amount {amount}", () =>
    {
        account.Withdraw(amount);
        Console.WriteLine($"Withdrawal OK. New balance = {account.Balance}");
    });
}

void DoDeposit()
{
    var account = ReadAccount("Account id: ", "DEPOSIT");
    if (account is null || !TryReadAmount("Amount to deposit: ", "DEPOSIT", out decimal amount))
        return;

    Execute("DEPOSIT", $"account {account.Id}, amount {amount}", () =>
    {
        account.Deposit(amount);
        Console.WriteLine($"Deposit OK. New balance = {account.Balance}");
    });
}

void DoTransfer()
{
    var from = ReadAccount("From account id: ", "TRANSFER");
    if (from is null) return;
    var to = ReadAccount("To account id: ", "TRANSFER");
    if (to is null || !TryReadAmount("Amount to transfer: ", "TRANSFER", out decimal amount))
        return;

    Execute("TRANSFER", $"from {from.Id} to {to.Id}, amount {amount}", () =>
    {
        BankAccount.Transfer(from, to, amount);
        Console.WriteLine($"Transfer OK. {from.CustomerName} = {from.Balance}, {to.CustomerName} = {to.Balance}");
    });
}

void Execute(string operation, string details, Action action)
{
    try
    {
        action();
    }
    catch (InsufficientFundsException ex)
    {
        Console.WriteLine($"ERROR: {ex.Message}");
        Console.WriteLine($"       Balance = {ex.Balance}, requested = {ex.Requested}");
        LogFailure(operation, $"{details}: {ex.Message} (balance = {ex.Balance}, requested = {ex.Requested})");
    }
    catch (ArgumentOutOfRangeException)
    {
        Console.WriteLine("Invalid amount: it must be greater than zero.");
        LogFailure(operation, $"{details}: invalid amount");
    }
    catch (ArgumentException ex)
    {
        Console.WriteLine($"ERROR: {ex.Message}");
        LogFailure(operation, $"{details}: {ex.Message}");
    }
    finally
    {
        Console.WriteLine("Operation finished.");
    }
}

BankAccount? ReadAccount(string prompt, string operation)
{
    Console.Write(prompt);
    string? input = Console.ReadLine();
    if (!int.TryParse(input, out int id))
    {
        Console.WriteLine("Invalid input");
        LogFailure(operation, $"invalid account id '{input}'");
        return null;
    }

    var account = accounts.Find(a => a.Id == id);
    if (account is null)
    {
        Console.WriteLine("Account not found");
        LogFailure(operation, $"account {id} not found");
    }
    return account;
}

bool TryReadAmount(string prompt, string operation, out decimal amount)
{
    Console.Write(prompt);
    string? input = Console.ReadLine();
    if (decimal.TryParse(input, out amount))
        return true;

    Console.WriteLine("Invalid input");
    LogFailure(operation, $"invalid amount '{input}'");
    return false;
}

void PrintAccounts()
{
    Console.WriteLine($"{"Id",-4}{"Customer",-10}{"Balance",8}");
    foreach (var a in accounts)
        Console.WriteLine($"{a.Id,-4}{a.CustomerName,-10}{a.Balance,8}");
}

StreamWriter? OpenLog()
{
    try
    {
        return new StreamWriter(LogPath, append: true) { AutoFlush = true };
    }
    catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
    {
        Console.WriteLine($"Warning: cannot open {LogPath} ({ex.Message}). Failed operations will not be logged.");
        return null;
    }
}

void LogFailure(string operation, string reason)
{
    if (log is null)
        return;

    try
    {
        log.WriteLine($"{DateTime.Now:yyyy-MM-dd HH:mm:ss} | {operation} | {reason}");
    }
    catch (IOException ex)
    {
        Console.WriteLine($"Warning: could not write to {LogPath} ({ex.Message}).");
    }
}
