# BankLab — Mini Lab: Catching a Custom Exception

.NET Technology, Chapter 3: OOP with C#.

## Run

- From source: `dotnet run`
- Prebuilt: `publish\BankLab.exe` (Windows x64, needs the .NET 10 runtime)

Commands: `w` withdraw, `d` deposit, `t` transfer, `l` list accounts, `q` quit.
Failed operations are appended to `failed_operations.log` in the current folder.

## Files

| File | Content |
|---|---|
| `InsufficientFundsException.cs` | Task 1: custom exception with `Balance` and `Requested` |
| `BankAccount.cs` | Task 2: `Withdraw`; section 7: `Deposit`, `Transfer` (reuses `Withdraw`) |
| `Program.cs` | Tasks 3–4: five random accounts, `try / catch / finally`; section 7: loop until `q`, failure log with `using` + `StreamWriter` |

## Section 7 — observing the exception in the debugger

1. Visual Studio: *Debug → Windows → Exception Settings* (Ctrl+Alt+E).
2. Under *Common Language Runtime Exceptions*, tick `InsufficientFundsException` (add it with the `+` button if needed).
3. Run with F5 and withdraw more than the balance: execution stops on the `throw` in `BankAccount.Withdraw`.
4. Press F10 to step: execution jumps to the `catch (InsufficientFundsException ex)` block in `Program.cs`.
