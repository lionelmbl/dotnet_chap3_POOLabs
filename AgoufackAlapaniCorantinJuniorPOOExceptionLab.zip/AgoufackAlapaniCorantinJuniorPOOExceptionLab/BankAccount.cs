public class BankAccount
{
    public int Id { get; set; }
    public string CustomerName { get; set; } = "";
    public decimal Balance { get; set; }

    public void Withdraw(decimal amount)
    {
        if (amount <= 0)
            throw new ArgumentOutOfRangeException(nameof(amount), amount, "Amount must be greater than zero.");

        if (amount > Balance)
            throw new InsufficientFundsException(Balance, amount);

        Balance -= amount;
    }

    public void Deposit(decimal amount)
    {
        if (amount <= 0)
            throw new ArgumentOutOfRangeException(nameof(amount), amount, "Amount must be greater than zero.");

        Balance += amount;
    }

    public static void Transfer(BankAccount from, BankAccount to, decimal amount)
    {
        if (ReferenceEquals(from, to))
            throw new ArgumentException("Cannot transfer to the same account.");

        from.Withdraw(amount);
        to.Deposit(amount);
    }
}
