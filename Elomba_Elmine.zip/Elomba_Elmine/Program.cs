﻿using System;
using System.Collections.Generic;
using System.IO;

//task 3 and 4 : the main
var rnd = new Random();
string [] names = {"John", "Jane", "Bob", "Alice", "Michael"};
var accounts = new List<BankAccount>();

//create 5 bank accounts with id 1..5 and random balance between 5000 and 100000 then display them
for (int i = 0 ; i < 5; i ++){
    var acc = new BankAccount{
        Id = i + 1,
        CustomerName = names[i],
        Balance = rnd.Next(5000, 100000)
    };
    accounts.Add(acc);
    Console.WriteLine($"Account {acc.Id}: {acc.CustomerName} - Balance: {acc.Balance}");
}

//read id and amount, find the account, try {withdraw}, catch{...} and finally{...}
Console.Write("Enter account ID: ");
bool idOk = int.TryParse(Console.ReadLine(), out int id);
Console.Write("Enter withdrawal amount: ");
bool amountOk = decimal.TryParse(Console.ReadLine(), out decimal amount);
var account = accounts.FirstOrDefault(a => a.Id == id);

if (!idOk || !amountOk){
    Console.WriteLine("Invalid input");
}

// unknown account id, display "Account not found and not a number input display "Invalid input"
else{
    var found = accounts.FirstOrDefault(a => a.Id == id);
    if (found == null){
        Console.WriteLine("Account not found.");
    }
    else{
        try{
            found.Withdraw(amount);
            Console.WriteLine($"Withdrawal successful. New balance: {found.Balance}");
        }
        catch (ArgumentOutOfRangeException ex){
            Console.WriteLine($"Invalid withdrawal amount: {ex.Message}");
        }
        catch (InsufficientFundsException ex){
            Console.WriteLine($"Insufficient bank account balance. Available balance: {ex.Balance}, Requested: {ex.Requested}");
        }
        finally{
            Console.WriteLine("Transaction ended.");
        }
    }
}

//part 7 : going further (optional)
//loop until the user types q, with withdraw / deposit / transfer,
//and every failed operation is written to a file using "using" and StreamWriter
Console.WriteLine();
Console.WriteLine("=== Part 7: more operations (type q to quit) ===");
string logPath = "failed_operations.txt";

using (var log = new StreamWriter(logPath, append: true)){
    log.AutoFlush = true;

    while (true){
        Console.Write("Operation (w = withdraw, d = deposit, t = transfer, q = quit): ");
        string? choice = Console.ReadLine()?.Trim().ToLower();

        if (choice == "q") break;

        if (choice != "w" && choice != "d" && choice != "t"){
            Console.WriteLine("Invalid input");
            log.WriteLine($"{DateTime.Now:yyyy-MM-dd HH:mm:ss} | Invalid menu choice: {choice}");
            continue;
        }

        //source account (for a transfer this is the account money is taken from)
        Console.Write(choice == "t" ? "From account ID: " : "Account ID: ");
        bool opIdOk = int.TryParse(Console.ReadLine(), out int opId);

        //destination account (transfer only)
        int toId = 0;
        bool toIdOk = true;
        if (choice == "t"){
            Console.Write("To account ID: ");
            toIdOk = int.TryParse(Console.ReadLine(), out toId);
        }

        Console.Write("Amount: ");
        bool opAmountOk = decimal.TryParse(Console.ReadLine(), out decimal opAmount);

        if (!opIdOk || !toIdOk || !opAmountOk){
            Console.WriteLine("Invalid input");
            log.WriteLine($"{DateTime.Now:yyyy-MM-dd HH:mm:ss} | Invalid input (operation '{choice}')");
            continue;
        }

        var opAccount = accounts.Find(a => a.Id == opId);
        var toAccount = accounts.Find(a => a.Id == toId);

        if (opAccount == null || (choice == "t" && toAccount == null)){
            Console.WriteLine("Account not found.");
            log.WriteLine($"{DateTime.Now:yyyy-MM-dd HH:mm:ss} | Account not found (operation '{choice}', id {opId}" + (choice == "t" ? $" -> {toId})" : ")"));
            continue;
        }

        try{
            if (choice == "w"){
                opAccount.Withdraw(opAmount);
                Console.WriteLine($"Withdrawal successful. New balance: {opAccount.Balance}");
            }
            else if (choice == "d"){
                opAccount.Deposit(opAmount);
                Console.WriteLine($"Deposit successful. New balance: {opAccount.Balance}");
            }
            else{
                BankAccount.Transfer(opAccount, toAccount!, opAmount);
                Console.WriteLine($"Transfer successful. Balance of account {opAccount.Id}: {opAccount.Balance}, balance of account {toAccount!.Id}: {toAccount.Balance}");
            }
        }
        catch (ArgumentOutOfRangeException ex){
            Console.WriteLine($"Invalid amount: {ex.Message}");
            log.WriteLine($"{DateTime.Now:yyyy-MM-dd HH:mm:ss} | Invalid amount (operation '{choice}', account {opId}, amount {opAmount}): {ex.Message}");
        }
        catch (InsufficientFundsException ex){
            Console.WriteLine($"Insufficient bank account balance. Available balance: {ex.Balance}, Requested: {ex.Requested}");
            log.WriteLine($"{DateTime.Now:yyyy-MM-dd HH:mm:ss} | Insufficient funds (operation '{choice}', account {opId}): balance {ex.Balance}, requested {ex.Requested}");
        }
        finally{
            Console.WriteLine("Operation finished.");
        }
    }
}
Console.WriteLine($"Goodbye. Failed operations (if any) were saved in {logPath}");

//task 1
public class InsufficientFundsException : Exception{
    //properties balance and requested (get only)
    public decimal Balance { get; }
    public decimal Requested { get; }
    //the three standard constructors: empty, message, message + inner exception
    public InsufficientFundsException() : base() {}
    public InsufficientFundsException(string message) : base(message) {}
    public InsufficientFundsException(string message, Exception inner) : base(message, inner) {}
    //constructor with balance and requested parameters and message "Insufficient bank account balance"
    public InsufficientFundsException(decimal balance, decimal requested) : base("Insufficient bank account balance"){
        Balance = balance;
        Requested = requested;
    }
}

//task 2
public class BankAccount{
    public int Id {get; set;}
    public string CustomerName {get; set;} = "";
    public decimal Balance {get; set;}

    public void Withdraw(decimal amount){
        //amount less than 0, throw ArgumentOutOfRangeException
        if(amount < 0){
            throw new ArgumentOutOfRangeException("amount", "Amount must be greater than 0");
        }
        //amount greater than balance, throw InsufficientFundsException
        if (amount > Balance){
            throw new InsufficientFundsException(Balance, amount);
        }
        //otherwise, subtract amount from balance
        Balance -= amount;
    }

    //part 7 : deposit adds money to the balance (amount must be positive)
    public void Deposit(decimal amount){
        if (amount <= 0){
            throw new ArgumentOutOfRangeException("amount", "Amount must be greater than 0");
        }
        Balance += amount;
    }

    //part 7 : transfer reuses Withdraw, so if the withdrawal fails nothing is deposited
    public static void Transfer(BankAccount from, BankAccount to, decimal amount){
        from.Withdraw(amount);
        to.Deposit(amount);
    }
}