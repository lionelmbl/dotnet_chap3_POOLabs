﻿
using System;
using System.Collections.Generic;

// Task 1: Create a custom exception
public class InsufficientFundsException : Exception
{
    public decimal Balance { get; }
    public decimal Requested { get; }

    public InsufficientFundsException() { }

    public InsufficientFundsException(string message)
        : base(message) { }

    public InsufficientFundsException(string message, Exception inner)
        : base(message, inner) { }

    public InsufficientFundsException(decimal balance, decimal requested)
        : base("Insufficient bank account balance")
    {
        Balance = balance;
        Requested = requested;
    }
}

// Task 2: BankAccount class
public class BankAccount
{
    public int Id { get; set; }
    public string CustomerName { get; set; } = "";
    public decimal Balance { get; set; }

    public void Withdraw(decimal amount)
    {
        if (amount <= 0)
            throw new ArgumentOutOfRangeException(
                nameof(amount), "Invalid amount");

        if (amount > Balance)
            throw new InsufficientFundsException(
                Balance, amount);

        Balance -= amount;
    }
}

// Tasks 3 and 4: Main program
class Program
{
    static void Main()
    {
        var rnd = new Random();

        string[] names =
        {
            "Ada", "Linus", "Grace", "Oceanne", "Margaret"
        };

        var accounts = new List<BankAccount>();

        // Task 3: Create five accounts
        for (int i = 0; i < names.Length; i++)
        {
            accounts.Add(new BankAccount
            {
                Id = i + 1,
                CustomerName = names[i],
                Balance = rnd.Next(5000, 100001)
            });
        }

        Console.WriteLine("Id    Customer    Balance");

        foreach (var account in accounts)
        {
            Console.WriteLine(
                $"{account.Id,-6}{account.CustomerName,-12}{account.Balance}");
        }

        // Task 4: Read input
        try
        {
            Console.Write("\nAccount id: ");

            if (!int.TryParse(Console.ReadLine(), out int id))
            {
                Console.WriteLine("Invalid input");
                return;
            }

            BankAccount? account = accounts.Find(a => a.Id == id);

            if (account == null)
            {
                Console.WriteLine("Account not found");
                return;
            }

            Console.Write("Amount to withdraw: ");

            if (!decimal.TryParse(
                Console.ReadLine(), out decimal amount))
            {
                Console.WriteLine("Invalid input");
                return;
            }

            account.Withdraw(amount);

            Console.WriteLine(
                $"Withdrawal OK. New balance = {account.Balance}");
        }
        catch (InsufficientFundsException ex)
        {
            Console.WriteLine($"ERROR: {ex.Message}");
            Console.WriteLine(
                $"       Balance = {ex.Balance}, requested = {ex.Requested}");
        }
        catch (ArgumentOutOfRangeException ex)
        {
            Console.WriteLine($"ERROR: {ex.Message}");
        }
        finally
        {
            Console.WriteLine("Operation finished.");
        }
    }
}